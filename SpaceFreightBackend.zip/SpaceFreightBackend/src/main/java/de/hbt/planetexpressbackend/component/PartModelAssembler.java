package de.hbt.planetexpressbackend.component;

import de.hbt.planetexpressbackend.boundary.PartController;
import de.hbt.planetexpressbackend.entity.Part;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;
import  static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class PartModelAssembler implements RepresentationModelAssembler<Part, EntityModel<Part>> {

    @Override
    public EntityModel<Part> toModel(Part part) {
        return null;
    }






}
