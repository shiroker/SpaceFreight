package de.hbt.planetexpressbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlanetExpressBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlanetExpressBackendApplication.class, args);
	}

}
