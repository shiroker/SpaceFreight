package de.hbt.planetexpressbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlanetExpressBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
